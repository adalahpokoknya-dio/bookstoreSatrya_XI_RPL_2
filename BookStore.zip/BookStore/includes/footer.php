<!-- Footer umum untuk halaman publik. -->

    </div>

</main>

<footer class="border-top bg-white py-3 mt-4">

    <div class="container text-center text-muted small">

        © <?= date('Y') ?> BookStore —
        Temukan buku terbaik Anda.

    </div>

</footer>

<!-- Bootstrap menyediakan komponen responsif dan app.js menangani konfirmasi hapus. -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/app.js"></script>

</body>

</html>
