<?php

// Memulai session sekali untuk autentikasi user dan admin di seluruh aplikasi.

if (session_status() === PHP_SESSION_NONE) {
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');

    if (strpos($scriptPath, '/admin/') !== false) {
        session_name('bookstore_admin_session');
    } else {
        session_name('bookstore_user_session');
    }

    session_start();
}

// Mengatur kredensial MySQL XAMPP; ubah jika konfigurasi lokal berbeda.

define('DB_HOST', 'localhost');
define('DB_NAME', 'bookstore');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', 3307);

// Membuka koneksi MySQLi dengan charset UTF-8 agar teks Indonesia tersimpan benar.

$conn = new mysqli(
    DB_HOST,
    DB_USER,
    DB_PASS,
    DB_NAME,
    DB_PORT
);

if ($conn->connect_error) {

    die(
        'Koneksi database gagal: ' .
        $conn->connect_error
    );
}

$conn->set_charset('utf8mb4');

?>