<?php

// Memuat koneksi dan session agar fungsi otorisasi tersedia untuk setiap halaman.

require_once __DIR__ . '/database.php';

// Mengamankan halaman user: pengunjung akan diarahkan ke login bila belum autentikasi.

function requireUser()
{
    if (empty($_SESSION['user'])) {

        header('Location: login.php');
        exit;
    }
}

// Mengamankan halaman admin dengan path login admin.

function requireAdmin()
{
    if (empty($_SESSION['admin'])) {

        header('Location: login.php');
        exit;
    }
}

// Menghindari XSS saat menampilkan data yang berasal dari database atau form.

function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

// Menyimpan pesan satu-kali-tampil pada session.

function flash($key, $message = null)
{
    if ($message !== null) {

        $_SESSION['flash'][$key] = $message;

        return '';
    }

    $m = $_SESSION['flash'][$key] ?? '';

    unset($_SESSION['flash'][$key]);

    return $m;
}

?>
