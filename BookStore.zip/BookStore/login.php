<?php

// Memverifikasi password hash user lalu menyimpan identitas minimum pada session.

require_once 'config/auth.php';

if (!empty($_SESSION['user'])) {

    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        'SELECT *
         FROM user
         WHERE email = ?'
    );

    $stmt->bind_param('s', $email);
    $stmt->execute();

    $u = $stmt->get_result()->fetch_assoc();

    if (
        $u &&
        password_verify($password, $u['password'])
    ) {

        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id'    => $u['id_user'],
            'nama'  => $u['nama'],
            'email' => $u['email']
        ];

        header('Location: index.php');
        exit;
    }

    flash(
        'error',
        'Email atau password tidak tepat.'
    );
}

$pageTitle = 'Masuk';

require 'includes/header.php';

?>

<!-- Form login user memakai sesi yang dikelola config/auth.php. -->

<div class="card shadow-sm auth-card">

    <div class="card-body p-4">

        <h1 class="h3 mb-3">
            Masuk User
        </h1>

        <form method="post">

            <div class="mb-3">

                <label class="form-label">
                    Email
                </label>

                <input
                    required
                    type="email"
                    name="email"
                    class="form-control"
                >

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Password
                </label>

                <input
                    required
                    type="password"
                    name="password"
                    class="form-control"
                >

            </div>

            <button class="btn btn-primary w-100">
                Masuk
            </button>

        </form>

        <p class="text-center mt-3 mb-0">

            Belum punya akun?

            <a href="register.php">
                Daftar
            </a>

        </p>

        <p class="text-center mt-2 mb-0 small">

            <a href="admin/login.php">
                Login admin
            </a>

        </p>

    </div>

</div>

<?php
require 'includes/footer.php';
?>