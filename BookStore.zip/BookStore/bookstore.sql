-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Nov 07, 2026 at 12:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(10) UNSIGNED NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `email`, `password`, `created_at`) VALUES
(1, 'Administrator', 'admin@bookstore.test', '$2y$10$K1PCdz2QnIV284OH.BK1rOzxUlEoG/f3oacL6YivUdgarcgasCZu2', '2026-08-06 07:30:26');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(10) UNSIGNED NOT NULL,
  `id_kategori` int(10) UNSIGNED NOT NULL,
  `judul_buku` varchar(200) NOT NULL,
  `penulis` varchar(150) NOT NULL,
  `penerbit` varchar(150) NOT NULL,
  `tahun_terbit` smallint(5) UNSIGNED NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `judul_buku`, `penulis`, `penerbit`, `tahun_terbit`, `harga`, `stok`, `deskripsi`, `gambar`) VALUES
(1, 1, 'Laut Bercerita', 'Leila S. Chudori', 'Gramedia', 2017, 115000.00, 16, 'Novel tentang persahabatan dan perjuangan di masa lalu.', 'book_480d6120d4fcfdfc.jpg'),
(2, 2, 'The Technology Book', 'DK Ideas', 'Penguin Books', 2024, 95000.00, 12, 'Panduan Teknologi untuk masyarakat awam', 'book_1f38f908c3cca700.jpg'),
(3, 3, 'Atomic Habits', 'James Clear', 'Gramedia', 2019, 108000.00, 0, 'Strategi membangun kebiasaan kecil yang konsisten.', 'book_0a3ee4591dec6de2.jpg'),
(4, 1, 'Wuthering Heights', 'Emily Bronte', 'Penguin Books', 2002, 75000.00, 18, 'Mengisahkan cinta gelap, obsesif, dan balas dendam', 'book_0d9e3cda37aa909a.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `id_buku` int(10) UNSIGNED NOT NULL,
  `jumlah` int(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(10) UNSIGNED NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(5, 'Biografi'),
(3, 'Bisnis'),
(1, 'Novel'),
(4, 'Pendidikan'),
(2, 'Teknologi');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `tanggal_order` datetime NOT NULL,
  `total_harga` decimal(12,2) NOT NULL,
  `status` enum('Menunggu Pembayaran','Menunggu Verifikasi','Disetujui','Ditolak') NOT NULL DEFAULT 'Menunggu Pembayaran',
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `catatan_admin` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id_order`, `id_user`, `tanggal_order`, `total_harga`, `status`, `metode_pembayaran`, `bukti_pembayaran`, `catatan_admin`) VALUES
(1, 1, '2026-09-03 08:17:37', 75000.00, 'Disetujui', NULL, 'payment_1_10ca111fd87d16ba.jpg', ''),
(2, 2, '2026-10-22 07:46:59', 75000.00, 'Ditolak', NULL, 'payment_2_d57e31dca7e69d3c.jpg', ''),
(3, 3, '2026-11-03 10:36:00', 225000.00, 'Disetujui', 'E-Wallet', 'payment_3_01a8d3eef0abd3dd.jpg', ''),
(4, 3, '2026-11-05 07:55:06', 75000.00, 'Disetujui', 'E-Wallet', 'payment_4_14482496009cba9d.jpg', ''),
(5, 3, '2026-11-07 16:21:14', 115000.00, 'Menunggu Pembayaran', 'Kartu Kredit', NULL, NULL),
(6, 3, '2026-11-07 16:21:41', 115000.00, 'Menunggu Pembayaran', 'Kartu Kredit', NULL, NULL),
(7, 3, '2026-11-07 16:22:38', 115000.00, 'Menunggu Pembayaran', 'E-Wallet', NULL, NULL),
(8, 3, '2026-11-07 16:25:59', 95000.00, 'Menunggu Pembayaran', 'Kartu Kredit', NULL, NULL),
(9, 3, '2026-11-07 16:39:48', 95000.00, 'Menunggu Pembayaran', 'Transfer Bank', NULL, NULL),
(10, 3, '2026-11-07 16:41:44', 95000.00, 'Ditolak', 'Transfer Bank', 'payment_10_d62d392b4916d2d2.jpg', ''),
(11, 3, '2026-11-07 18:36:14', 115000.00, 'Disetujui', 'Kartu Kredit', 'payment_11_9c90175390051625.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id_detail` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_buku` int(10) UNSIGNED NOT NULL,
  `jumlah` int(10) UNSIGNED NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id_detail`, `id_order`, `id_buku`, `jumlah`, `subtotal`) VALUES
(1, 1, 4, 1, 75000.00),
(2, 2, 4, 1, 75000.00),
(3, 3, 4, 3, 225000.00),
(4, 4, 4, 1, 75000.00),
(5, 5, 1, 1, 115000.00),
(6, 6, 1, 1, 115000.00),
(7, 7, 1, 1, 115000.00),
(8, 8, 2, 1, 95000.00),
(9, 9, 2, 1, 95000.00),
(10, 10, 2, 1, 95000.00),
(11, 11, 1, 1, 115000.00);

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) UNSIGNED NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `nomor_telepon` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `email`, `password`, `alamat`, `nomor_telepon`, `created_at`) VALUES
(1, 'USER 1', 'user@gmail.com', '$2y$10$PiUFnUpwDjUutKGd.xe5AOUTRyn1XVomA2tiZJUTjfwYa7PDBL25m', 'jalan cipinang muara', '1234-5678-9101', '2026-09-03 01:16:49'),
(2, 'user 2', 'apaajajadi@gmail.com', '$2y$10$hr3E6oFyuTikvoYklu9HEuoUhsqhU54ChS9cozMDB5e2dkr2ub4vu', 'jalan cipinang besar', '1234-5678-9101', '2026-10-22 00:43:54'),
(3, 'user 13', 'adalahpokoknya@gmail.com', '$2y$10$G4O9CXtQWKwa0klUvzLvFuMFNe5b2ebqNubb/ixwBZyv5Xu0Gjm/i', 'jl warna', '1234-5678-9101', '2026-11-03 02:55:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `fk_buku_kategori` (`id_kategori`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`),
  ADD UNIQUE KEY `uq_cart_user_buku` (`id_user`,`id_buku`),
  ADD KEY `fk_cart_buku` (`id_buku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`),
  ADD UNIQUE KEY `nama_kategori` (`nama_kategori`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `fk_order_user` (`id_user`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_detail_order` (`id_order`),
  ADD KEY `fk_detail_buku` (`id_buku`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `fk_pesan_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id_detail` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `fk_buku_kategori` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON UPDATE CASCADE;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_buku` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`),
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `fk_detail_buku` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`),
  ADD CONSTRAINT `fk_detail_order` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id_order`) ON DELETE CASCADE;

--
-- Constraints for table `pesan`
--
ALTER TABLE `pesan`
  ADD CONSTRAINT `fk_pesan_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
