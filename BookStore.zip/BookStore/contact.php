<?php

// Hanya user login yang dapat menyimpan pesan ke tabel pesan.

require_once 'config/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    requireUser();

    $pesan = trim($_POST['pesan'] ?? '');

    if ($pesan === '') {

        flash(
            'error',
            'Pesan tidak boleh kosong.'
        );
    }

    else {

        $uid = $_SESSION['user']['id'];

        $stmt = $conn->prepare(
            'INSERT INTO pesan
            (id_user, pesan, tanggal)
            VALUES (?, ?, NOW())'
        );

        $stmt->bind_param(
            'is',
            $uid,
            $pesan
        );

        $stmt->execute();

        flash(
            'success',
            'Pesan sudah dikirim ke admin.'
        );

        header('Location: contact.php');
        exit;
    }
}

$pageTitle = 'Kontak';

require 'includes/header.php';

?>

<!-- Form pesan bertaut ke tabel pesan. -->

<div class="card shadow-sm auth-card">

    <div class="card-body p-4">

        <h1 class="h3">
            Hubungi Admin
        </h1>

        <p class="text-muted">
            Ada pertanyaan? Kirimkan pesan kepada kami.
        </p>

        <?php if (empty($_SESSION['user'])) : ?>

            <div class="alert alert-info">

                Silakan
                <a href="login.php">masuk</a>
                terlebih dahulu untuk mengirim pesan.

            </div>

        <?php else : ?>

            <form method="post">

                <textarea
                    class="form-control mb-3"
                    required
                    name="pesan"
                    rows="5"
                    placeholder="Tulis pesan Anda..."
                ></textarea>

                <button class="btn btn-primary">
                    Kirim Pesan
                </button>

            </form>

        <?php endif; ?>

    </div>

</div>

<?php
require 'includes/footer.php';
?>
