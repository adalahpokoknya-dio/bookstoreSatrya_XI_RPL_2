<?php
// Checkout memakai transaksi agar pesanan, detail, stok, dan pengosongan cart konsisten.
require_once 'config/auth.php';

requireUser();
$uid = $_SESSION['user']['id'];

$stmt = $conn->prepare(
    'SELECT c.*, b.judul_buku, b.harga, b.stok
    FROM cart c
    JOIN buku b ON b.id_buku = c.id_buku
    WHERE c.id_user = ?'
);
$stmt->bind_param('i', $uid);
$stmt->execute();

$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$total = 0;

foreach ($items as $i) {
    $total += $i['harga'] * $i['jumlah'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$items) {
        flash('error', 'Keranjang kosong.');
        header('Location: cart.php');
        exit;
    }

    $paymentMethod = $_POST['metode_pembayaran'] ?? '';
    $allowedMethods = [
        'Transfer Bank',
        'Kartu Kredit',
        'E-Wallet',
        'Bayar di Tempat',
    ];

    if (!in_array($paymentMethod, $allowedMethods, true)) {
        flash('error', 'Pilih metode pembayaran yang tersedia.');
    } else {
        $conn->begin_transaction();

        try {
            foreach ($items as $i) {
                if ($i['jumlah'] > $i['stok']) {
                    throw new Exception('Stok ' . $i['judul_buku'] . ' tidak mencukupi.');
                }
            }

            $status = 'Menunggu Pembayaran';
            $order = $conn->prepare(
                'INSERT INTO orders (id_user, tanggal_order, total_harga, status, metode_pembayaran)
                VALUES (?, NOW(), ?, ?, ?)'
            );
            $order->bind_param('idss', $uid, $total, $status, $paymentMethod);
            $order->execute();

            $oid = $conn->insert_id;

            foreach ($items as $i) {
                $sub = $i['harga'] * $i['jumlah'];

                $detail = $conn->prepare(
                    'INSERT INTO order_detail (id_order, id_buku, jumlah, subtotal)
                    VALUES (?, ?, ?, ?)'
                );
                $detail->bind_param('iiid', $oid, $i['id_buku'], $i['jumlah'], $sub);
                $detail->execute();

                $stock = $conn->prepare(
                    'UPDATE buku SET stok = stok - ? WHERE id_buku = ?'
                );
                $stock->bind_param('ii', $i['jumlah'], $i['id_buku']);
                $stock->execute();
            }

            $clear = $conn->prepare('DELETE FROM cart WHERE id_user = ?');
            $clear->bind_param('i', $uid);
            $clear->execute();

            $conn->commit();
            header('Location: order_success.php?id=' . $oid);
            exit;
        } catch (Throwable $e) {
            $conn->rollback();
            flash('error', $e->getMessage());
        }
    }
}

$pageTitle = 'Checkout';
require 'includes/header.php';
?>

<!-- Konfirmasi checkout menyimpan metode mock; bukti tetap diunggah setelah pesanan dibuat. -->
<div class="card shadow-sm auth-card">
    <div class="card-body p-4">
        <h1 class="h3">Konfirmasi Checkout</h1>

        <p>
            Total pembayaran:
            <strong class="price">Rp<?= number_format($total, 0, ',', '.') ?></strong>
        </p>

        <p class="text-muted">
            Metode berikut hanya pilihan simulasi. Anda tetap perlu mengunggah bukti foto setelah pesanan dibuat.
        </p>

        <form method="post">
            <label class="form-label" for="metode_pembayaran">Metode pembayaran</label>

            <select
                required
                class="form-select mb-3"
                id="metode_pembayaran"
                name="metode_pembayaran"
            >
                <option value="">Pilih metode</option>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="Kartu Kredit">Kartu Kredit</option>
                <option value="E-Wallet">E-Wallet</option>
                <option value="Bayar di Tempat">Bayar di Tempat</option>
            </select>

            <button class="btn btn-primary" <?= !$items ? 'disabled' : '' ?>>
                Buat Pesanan
            </button>
            <a href="cart.php" class="btn btn-light">Kembali</a>
        </form>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
