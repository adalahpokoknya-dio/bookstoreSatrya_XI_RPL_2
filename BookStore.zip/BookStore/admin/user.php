<?php

// Admin hanya melihat data pelanggan tanpa menyediakan pengubahan password pelanggan.

$pageTitle = 'Data User';

require 'includes/header.php';

$rows = $conn->query(
    'SELECT
        id_user,
        nama,
        email,
        alamat,
        nomor_telepon,
        created_at
     FROM user
     ORDER BY id_user DESC'
);

?>

<!-- Tabel pelanggan terdaftar dari tabel user. -->

<h1 class="h3 mb-3">
    Data User
</h1>

<div class="card shadow-sm table-responsive">

    <table class="table mb-0">

        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th>Terdaftar</th>
        </tr>

        <?php while ($u = $rows->fetch_assoc()) : ?>

            <tr>

                <td><?= $u['id_user'] ?></td>

                <td><?= e($u['nama']) ?></td>

                <td><?= e($u['email']) ?></td>

                <td><?= e($u['alamat']) ?></td>

                <td><?= e($u['nomor_telepon']) ?></td>

                <td><?= e($u['created_at']) ?></td>

            </tr>

        <?php endwhile; ?>

    </table>

</div>

<?php
require 'includes/footer.php';
?>
