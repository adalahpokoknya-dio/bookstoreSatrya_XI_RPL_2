<?php

// Menggabungkan pesan dengan user pengirim untuk dibaca admin.

$pageTitle = 'Pesan';

require 'includes/header.php';

$rows = $conn->query(
    'SELECT
        p.*,
        u.nama,
        u.email
     FROM pesan p
     JOIN user u
        ON u.id_user = p.id_user
     ORDER BY p.tanggal DESC'
);

?>

<!-- Riwayat pesan pelanggan ke admin. -->

<h1 class="h3 mb-3">
    Pesan Masuk
</h1>

<div class="card shadow-sm table-responsive">

    <table class="table mb-0">

        <tr>
            <th>Pengirim</th>
            <th>Pesan</th>
            <th>Tanggal</th>
        </tr>

        <?php while ($p = $rows->fetch_assoc()) : ?>

            <tr>

                <td>

                    <?= e($p['nama']) ?>

                    <br>

                    <small>
                        <?= e($p['email']) ?>
                    </small>

                </td>

                <td>

                    <?= nl2br(e($p['pesan'])) ?>

                </td>

                <td>

                    <?= e($p['tanggal']) ?>

                </td>

            </tr>

        <?php endwhile; ?>

    </table>

</div>

<?php
require 'includes/footer.php';
?>