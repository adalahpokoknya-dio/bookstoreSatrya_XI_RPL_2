<?php

// Mengelola CRUD buku serta upload sampul
// yang hanya menerima gambar aman.

require_once '../config/auth.php';

requireAdmin();

/**
 * Upload sampul buku.
 */
function uploadCover($old = '')
{
    if (empty($_FILES['gambar']['name'])) {
        return $old;
    }

    $f = $_FILES['gambar'];

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    $mime = (new finfo(FILEINFO_MIME_TYPE))
        ->file($f['tmp_name']);

    if (
        $f['error'] !== UPLOAD_ERR_OK ||
        !isset($allowed[$mime]) ||
        $f['size'] > 2 * 1024 * 1024
    ) {
        throw new Exception(
            'Sampul harus JPG, PNG, atau WEBP maksimal 2 MB.'
        );
    }

    $name =
        'book_' .
        bin2hex(random_bytes(8)) .
        '.' .
        $allowed[$mime];

    $dir = __DIR__ . '/../uploads/books';

    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    move_uploaded_file(
        $f['tmp_name'],
        $dir . '/' . $name
    );

    return $name;
}

$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        $id = (int) ($_POST['id_buku'] ?? 0);

        $cat = (int) $_POST['id_kategori'];

        $judul = trim($_POST['judul_buku']);

        $penulis = trim($_POST['penulis']);

        $penerbit = trim($_POST['penerbit']);

        $tahun = (int) $_POST['tahun_terbit'];

        $harga = (float) $_POST['harga'];

        $stok = (int) $_POST['stok'];

        $desc = trim($_POST['deskripsi']);

        $gambar = uploadCover(
            $_POST['gambar_lama'] ?? ''
        );

        if (
            !$judul ||
            !$cat ||
            $harga < 0 ||
            $stok < 0
        ) {
            throw new Exception(
                'Data buku tidak valid.'
            );
        }

        if ($id) {

            $stmt = $conn->prepare(
                'UPDATE buku
                 SET
                    id_kategori=?,
                    judul_buku=?,
                    penulis=?,
                    penerbit=?,
                    tahun_terbit=?,
                    harga=?,
                    stok=?,
                    deskripsi=?,
                    gambar=?
                 WHERE id_buku=?'
            );

            $stmt->bind_param(
                'isssidissi',
                $cat,
                $judul,
                $penulis,
                $penerbit,
                $tahun,
                $harga,
                $stok,
                $desc,
                $gambar,
                $id
            );

            $stmt->execute();

            flash(
                'success',
                'Buku diperbarui.'
            );

        } else {

            $stmt = $conn->prepare(
                'INSERT INTO buku
                (
                    id_kategori,
                    judul_buku,
                    penulis,
                    penerbit,
                    tahun_terbit,
                    harga,
                    stok,
                    deskripsi,
                    gambar
                )
                VALUES
                (
                    ?,?,?,?,?,?,?,?,?
                )'
            );

            $stmt->bind_param(
                'isssidiss',
                $cat,
                $judul,
                $penulis,
                $penerbit,
                $tahun,
                $harga,
                $stok,
                $desc,
                $gambar
            );

            $stmt->execute();

            flash(
                'success',
                'Buku ditambahkan.'
            );
        }

        header('Location: buku.php');

        exit;

    } catch (Throwable $e) {

        flash(
            'error',
            $e->getMessage()
        );
    }
}

if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = $conn->prepare(
        'DELETE FROM buku
         WHERE id_buku=?'
    );

    $stmt->bind_param(
        'i',
        $id
    );

    if ($stmt->execute()) {

        flash(
            'success',
            'Buku dihapus.'
        );

    } else {

        flash(
            'error',
            'Buku tidak dapat dihapus karena sudah dipakai cart/pesanan.'
        );
    }

    header('Location: buku.php');

    exit;
}

if (isset($_GET['edit'])) {

    $id = (int) $_GET['edit'];

    $stmt = $conn->prepare(
        'SELECT *
         FROM buku
         WHERE id_buku=?'
    );

    $stmt->bind_param(
        'i',
        $id
    );

    $stmt->execute();

    $edit = $stmt
        ->get_result()
        ->fetch_assoc();
}

$cats = $conn->query(
    'SELECT *
     FROM kategori
     ORDER BY nama_kategori'
);

$pageTitle = 'Buku';

require 'includes/header.php';

$rows = $conn->query(
    'SELECT
        b.*,
        k.nama_kategori
     FROM buku b
     JOIN kategori k
        ON k.id_kategori = b.id_kategori
     ORDER BY b.id_buku DESC'
);

?>

<!-- Form buku terhubung ke kategori dan menyimpan file sampul ke uploads/books. -->

<h1 class="h3">

    Manajemen Buku

</h1>

<div class="card shadow-sm mb-4">

    <div class="card-body">

        <form
            method="post"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="id_buku"
                value="<?= e($edit['id_buku'] ?? '') ?>"
            >

            <input
                type="hidden"
                name="gambar_lama"
                value="<?= e($edit['gambar'] ?? '') ?>"
            >

            <div class="row g-3">

                <div class="col-md-4">

                    <label class="form-label">

                        Kategori

                    </label>

                    <select
                        required
                        class="form-select"
                        name="id_kategori"
                    >

                        <option value="">
                            Pilih
                        </option>

                        <?php while ($c = $cats->fetch_assoc()) : ?>

                            <option
                                value="<?= $c['id_kategori'] ?>"
                                <?= ($edit['id_kategori'] ?? 0) == $c['id_kategori'] ? 'selected' : '' ?>
                            >
                                <?= e($c['nama_kategori']) ?>
                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>

                <div class="col-md-8">

                    <label class="form-label">

                        Judul

                    </label>

                    <input
                        required
                        class="form-control"
                        name="judul_buku"
                        value="<?= e($edit['judul_buku'] ?? '') ?>"
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label">

                        Penulis

                    </label>

                    <input
                        required
                        class="form-control"
                        name="penulis"
                        value="<?= e($edit['penulis'] ?? '') ?>"
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label">

                        Penerbit

                    </label>

                    <input
                        required
                        class="form-control"
                        name="penerbit"
                        value="<?= e($edit['penerbit'] ?? '') ?>"
                    >

                </div>

                <div class="col-md-2">

                    <label class="form-label">

                        Tahun

                    </label>

                    <input
                        required
                        min="1"
                        type="number"
                        class="form-control"
                        name="tahun_terbit"
                        value="<?= e($edit['tahun_terbit'] ?? date('Y')) ?>"
                    >

                </div>

                <div class="col-md-2">

                    <label class="form-label">

                        Stok

                    </label>

                    <input
                        required
                        min="0"
                        type="number"
                        class="form-control"
                        name="stok"
                        value="<?= e($edit['stok'] ?? 0) ?>"
                    >

                </div>

                <div class="col-md-4">

                    <label class="form-label">

                        Harga

                    </label>

                    <input
                        required
                        min="0"
                        type="number"
                        class="form-control"
                        name="harga"
                        value="<?= e($edit['harga'] ?? '') ?>"
                    >

                </div>

                <div class="col-md-8">

                    <label class="form-label">

                        Sampul

                    </label>

                    <input
                        class="form-control"
                        type="file"
                        name="gambar"
                        accept="image/jpeg,image/png,image/webp"
                    >

                </div>

                <div class="col-12">

                    <label class="form-label">

                        Deskripsi

                    </label>

                    <textarea
                        class="form-control"
                        name="deskripsi"
                        rows="3"
                    ><?= e($edit['deskripsi'] ?? '') ?></textarea>

                </div>

            </div>

            <button
                class="btn btn-primary mt-3"
            >

                Simpan Buku

            </button>

            <?php if ($edit) : ?>

                <a
                    class="btn btn-light mt-3"
                    href="buku.php"
                >

                    Batal

                </a>

            <?php endif; ?>

        </form>

    </div>

</div>

<div class="card shadow-sm table-responsive">

    <table class="table mb-0">

        <thead>

            <tr>

                <th>Judul</th>

                <th>Kategori</th>

                <th>Harga</th>

                <th>Stok</th>

                <th>Aksi</th>

            </tr>

        </thead>

        <tbody>

            <?php while ($r = $rows->fetch_assoc()) : ?>

                <tr>

                    <td>

                        <?= e($r['judul_buku']) ?>

                    </td>

                    <td>

                        <?= e($r['nama_kategori']) ?>

                    </td>

                    <td>

                        Rp<?= number_format(
                            $r['harga'],
                            0,
                            ',',
                            '.'
                        ) ?>

                    </td>

                    <td>

                        <?= $r['stok'] ?>

                    </td>

                    <td>

                        <a
                            class="btn btn-sm btn-outline-primary"
                            href="?edit=<?= $r['id_buku'] ?>"
                        >

                            Edit

                        </a>

                        <a
                            class="btn btn-sm btn-outline-danger confirm-delete"
                            href="?delete=<?= $r['id_buku'] ?>"
                        >

                            Hapus

                        </a>

                    </td>

                </tr>

            <?php endwhile; ?>

        </tbody>

    </table>

</div>

<?php require 'includes/footer.php'; ?>
