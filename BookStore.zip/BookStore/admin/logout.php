<?php

// Mengakhiri session admin tanpa menghapus session user jika ada.

require_once '../config/auth.php';

unset($_SESSION['admin']);

session_regenerate_id(true);

header('Location: login.php');

exit;

?>
