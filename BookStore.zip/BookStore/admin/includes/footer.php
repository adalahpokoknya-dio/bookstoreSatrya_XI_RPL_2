<!-- Memuat JavaScript Bootstrap serta konfirmasi hapus untuk panel admin. -->

    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/app.js"></script>

</body>

</html>