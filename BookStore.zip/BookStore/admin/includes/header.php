<?php

require_once __DIR__ . '/../../config/auth.php';

requireAdmin();

?>

<!doctype html>

<html lang="id">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>

        <?= isset($pageTitle) ? e($pageTitle) . ' | ' : '' ?>

        Admin BookStore

    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="../assets/css/style.css"
        rel="stylesheet"
    >

</head>

<body>

<!-- Navigasi panel admin menuju setiap modul manajemen. -->

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

    <div class="container">

        <a
            class="navbar-brand fw-bold"
            href="dashboard.php"
        >
            BookStore Admin
        </a>

        <button
            class="navbar-toggler"
            data-bs-toggle="collapse"
            data-bs-target="#adminNav"
        >

            <span class="navbar-toggler-icon"></span>

        </button>

        <div
            class="collapse navbar-collapse"
            id="adminNav"
        >

            <ul class="navbar-nav ms-auto">

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="kategori.php"
                    >
                        Kategori
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="buku.php"
                    >
                        Buku
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="user.php"
                    >
                        User
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="order.php"
                    >
                        Pesanan
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="pesan.php"
                    >
                        Pesan
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="logout.php"
                    >
                        Keluar
                    </a>

                </li>

            </ul>

        </div>

    </div>

</nav>

<main class="py-4">

    <div class="container">

        <?php if ($m = flash('success')) : ?>

            <div class="alert alert-success">

                <?= e($m) ?>

            </div>

        <?php endif; ?>

        <?php if ($m = flash('error')) : ?>

            <div class="alert alert-danger">

                <?= e($m) ?>

            </div>

        <?php endif; ?>