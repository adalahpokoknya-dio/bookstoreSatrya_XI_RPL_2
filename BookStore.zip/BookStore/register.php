<?php

// Memproses pendaftaran dengan prepared statement dan hash password aman.

require_once 'config/auth.php';

if (!empty($_SESSION['user'])) {

    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $alamat = trim($_POST['alamat'] ?? '');
    $telp = trim($_POST['nomor_telepon'] ?? '');

    if (
        !$nama ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($password) < 6 ||
        !$alamat ||
        !$telp
    ) {

        flash(
            'error',
            'Lengkapi data; password minimal 6 karakter.'
        );
    }

    else {

        $check = $conn->prepare(
            'SELECT id_user
             FROM user
             WHERE email = ?'
        );

        $check->bind_param('s', $email);
        $check->execute();

        $exists = $check->get_result()->num_rows;

        if ($exists) {

            flash(
                'error',
                'Email sudah terdaftar.'
            );
        }

        else {

            $hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $conn->prepare(
                'INSERT INTO user
                (nama, email, password, alamat, nomor_telepon)
                VALUES (?, ?, ?, ?, ?)'
            );

            $stmt->bind_param(
                'sssss',
                $nama,
                $email,
                $hash,
                $alamat,
                $telp
            );

            $stmt->execute();

            flash(
                'success',
                'Registrasi berhasil. Silakan masuk.'
            );

            header('Location: login.php');
            exit;
        }
    }
}

$pageTitle = 'Daftar';

require 'includes/header.php';

?>

<!-- Form registrasi terhubung ke tabel user. -->

<div class="card shadow-sm auth-card">

    <div class="card-body p-4">

        <h1 class="h3 mb-3">
            Buat Akun
        </h1>

        <form method="post">

            <div class="mb-3">

                <label class="form-label">
                    Nama
                </label>

                <input
                    required
                    name="nama"
                    class="form-control"
                    value="<?= e($_POST['nama'] ?? '') ?>"
                >

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Email
                </label>

                <input
                    required
                    type="email"
                    name="email"
                    class="form-control"
                    value="<?= e($_POST['email'] ?? '') ?>"
                >

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Password
                </label>

                <input
                    required
                    type="password"
                    name="password"
                    minlength="6"
                    class="form-control"
                >

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Alamat
                </label>

                <textarea
                    required
                    name="alamat"
                    class="form-control"
                ><?= e($_POST['alamat'] ?? '') ?></textarea>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Nomor Telepon
                </label>

                <input
                    required
                    name="nomor_telepon"
                    class="form-control"
                    value="<?= e($_POST['nomor_telepon'] ?? '') ?>"
                >

            </div>

            <button class="btn btn-primary w-100">
                Daftar
            </button>

        </form>

        <p class="text-center mt-3 mb-0">

            Sudah punya akun?

            <a href="login.php">
                Masuk
            </a>

        </p>

    </div>

</div>

<?php
require 'includes/footer.php';
?>